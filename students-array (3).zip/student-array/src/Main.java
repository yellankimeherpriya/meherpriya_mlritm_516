public class Main {

	public static void main(String[] args) {
		int id;
		string fullName;
		date BirthDate;
		double avgMarks;
	}
	public class Student
	{
		obj.student(516,"David Luis",1997-10-12,90.0);
		System.out.println("%d %s %d %f",obj.student);
	}

}
