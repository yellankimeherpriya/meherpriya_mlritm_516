import java.util.Date;

/**
 * A fix-sized array of students
 * array length should always be equal to the number of stored elements
 * after the element was removed the size of the array should be equal to the number of stored elements
 * after the element was added the size of the array should be equal to the number of stored elements
 * null elements are not allowed to be stored in the array
 * 
 * You may add new methods, fields to this class, but DO NOT RENAME any given class, interface or method
 * DO NOT PUT any classes into packages
 *
 */
public class StudentGroup implements StudentArrayOperation {

	private Student[] students;
	
	/**
	 * DO NOT remove or change this constructor, it will be used during task check
	 * @param length
	 */
	public StudentGroup(int length) {
		this.students = new Student[length];
	}

	@Override
	public Student[] getStudents() {
		student o=obj.student();
		return null;
	}

	@Override
	public void setStudents(Student[] students) {
		this.student=obj.student();
	}

	@Override
	public Student getStudent(int index) {
		obj.student=new student(length)
		return null;
	}

	@Override
	public void setStudent(Student student, int index) {
		this.student=new student();
	}

	@Override
	public void addFirst(Student student) {
		student o(obj.student());
		return obj;

	@Override
	public void addLast(Student student) {
		student o(obj.student());
		return o;
	}

	@Override
	public void add(Student student, int index) {
		student o=add(student,length);
		o.add();
	}

	@Override
	public void remove(int index) {
		student o=remove(this.index.compareTo(other.index));
		o.remove();	
	}

	@Override
	public void remove(Student student) {
		this.student=o.student();
	}

	@Override
	public void removeFromIndex(int index) {
		remove.o=student(index.length);
	}

	@Override
	public void removeFromElement(Student student) {
		this.remove=remove;
	}

	@Override
	public void removeToIndex(int index) {
		remove.student=next.index(student);
		return  null;
	}

	@Override
	public void removeToElement(Student student) {
		remove.student=netTO.Element(student);
		return o;
	}

	

	@Override
	public Student[] getByBirthDate(Date date) {
		birthDate=get.student(birthDate);
		this.birthDate();
		return null;
	}

	@Override
	public Student[] getBetweenBirthDates(Date firstDate, Date lastDate) {
		student birthDate=new student(firstDate,lastDate);
		return null;
	}

	@Override
	public Student[] getNearBirthDate(Date date, int days) {
		student birthDate=new student(date,days);
		return null;
	}

	@Override
	public int getCurrentAgeByDate(int indexOfStudent) {
		student Age=o student(Date.compareTo(indexOfStudent);
		this.student=student(Age);
		return o;
	}

	@Override
	public Student[] getStudentsByAge(int age) {
		this.student=student(Age);
		return null;
	}

	@Override
	public Student[] getStudentsWithMaxAvgMark() {
		student o=nextTo.student(AvgMark());
		o.student();
		return null;
	}

	@Override
	public Student getNextStudent(Student student) {
		this.student=next.student;
		return null;
	}
}
